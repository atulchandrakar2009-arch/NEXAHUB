NexaHub starter website
=======================

Files
- index.html: complete self-contained website (HTML, CSS, JavaScript)

Run locally
1. Open index.html in a web browser.
2. No installation or API key is required.

Publish free with Cloudflare Pages (direct upload)
1. Create/sign in to a Cloudflare account.
2. Open Workers & Pages and choose to create a Pages project.
3. Choose the direct upload / upload assets option (the UI wording may change).
4. Upload the index.html file or a ZIP containing it.
5. Deploy and open the provided *.pages.dev address.

Alternative: GitHub + Cloudflare Pages
1. Create a GitHub repository and upload index.html.
2. In Cloudflare Pages, connect the repository.
3. For a plain HTML site, leave the build command empty and set the output directory to the repository root (often shown as /).
4. Deploy.

Notes
- The current version is a static prototype. Search, category filters, prompt builder, text tools, downloads, and focus timer work in the browser.
- Prompt Studio creates a prompt; it does not call an AI model.
- External resource links are provided for convenience. Check the third-party sites' terms.
- Do not upload copyrighted material you do not have permission to share.
- Before monetizing, publish original useful content and add clear About, Contact, Privacy Policy, and Terms pages. Ad approval and earnings are not guaranteed.
- No paid domain, backend, API, or database is required for this starter.


Latest design update:
- New animated welcome landing page with the text “NEXA HUB KINDLY WELCOMES YOU TO THE WORLD”.
- Click the Explore button to enter the main NexaHub website.
- Updated midnight-indigo aurora background with violet, cyan, and pink glow effects.
